Forward Focus Counseling — Google Business / Local SEO update

Upload the 8 HTML files in this folder to the ROOT of the GitHub repository and commit them.
They replace the existing HTML files with the same names.
No CSS, images, logo, CNAME, DNS, or GitHub Pages settings need to be changed.

Changes:
- Google Business Profile linked from every page footer
- Google Business Profile associated in ProfessionalService structured data
- Fees & Contact directions button now opens the Google Business/Maps listing
- Old Town Alexandria location wording strengthened on the contact page
- SimplePractice consultation links preserved
