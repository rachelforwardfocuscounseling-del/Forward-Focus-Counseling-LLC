Forward Focus Counseling: Group Counseling update

Files: group-counseling.html (new), index.html and services.html (updated).

IMPORTANT: These changes are based on earlier saved copies, not a verified current GitHub checkout. Compare index.html and services.html with your current repository before replacing them, to avoid overwriting newer edits.

Navigation: add <a href="group-counseling.html">Groups</a> before Fees & Contact in the site navigation on ALL other site pages too.

Upload group-counseling.html to the repository root alongside index.html and style.css. It reuses the existing style.css, logo.webp, and shared layout.

Add https://forwardfocuscounseling.org/group-counseling.html to sitemap.xml and submit sitemap to Search Console after publishing.

No $100 group rates are shown. Group start date and parent group weekly schedule are deliberately omitted until confirmed.
